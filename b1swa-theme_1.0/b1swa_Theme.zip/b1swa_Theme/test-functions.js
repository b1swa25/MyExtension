// QUICK TEST - Open console and run these commands to test if functions work:

// Test 1: Check if functions exist
console.log('enableAllProtection:', typeof window.enableAllProtection);
console.log('disableAllProtection:', typeof window.disableAllProtection);
console.log('clearFirewallLog:', typeof window.clearFirewallLog);

// Test 2: Try calling them directly
console.log('\n--- Testing enableAllProtection ---');
window.enableAllProtection();

setTimeout(() => {
    console.log('\n--- Testing disableAllProtection ---');
    window.disableAllProtection();
}, 2000);

setTimeout(() => {
    console.log('\n--- Testing clearFirewallLog ---');
    window.clearFirewallLog();
}, 4000);
