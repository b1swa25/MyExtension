// b1swa Suite - Background Service Worker
// Handles content blocking, security monitoring, and homoglyph detection

// ===== HOMOGLYPH DETECTION SYSTEM =====
const homoglyphMappings = {
    // Cyrillic lookalikes
    'а': 'a', 'е': 'e', 'о': 'o', 'р': 'p', 'с': 'c', 'у': 'y', 'х': 'x',
    'В': 'B', 'Е': 'E', 'К': 'K', 'М': 'M', 'Н': 'H', 'О': 'O', 'Р': 'P',
    'С': 'C', 'Т': 'T', 'У': 'Y', 'Х': 'X',
    // Greek lookalikes
    'α': 'a', 'β': 'b', 'ε': 'e', 'ι': 'i', 'ο': 'o', 'ρ': 'p', 'τ': 't', 'υ': 'y',
    'Α': 'A', 'Β': 'B', 'Ε': 'E', 'Ι': 'I', 'Κ': 'K', 'Μ': 'M', 'Ν': 'N',
    'Ο': 'O', 'Ρ': 'P', 'Τ': 'T', 'Υ': 'Y', 'Ζ': 'Z',
    // Other confusables
    '0': 'o', '1': 'l', '3': 'e', '5': 's', '8': 'b',
    'ı': 'i', 'ǀ': 'l', 'İ': 'I', 'Ι': 'I'
};

const legitimateDomains = [
    'google.com', 'facebook.com', 'amazon.com', 'microsoft.com', 'apple.com',
    'twitter.com', 'instagram.com', 'linkedin.com', 'github.com', 'youtube.com',
    'paypal.com', 'netflix.com', 'reddit.com', 'wikipedia.org', 'stackoverflow.com',
    'gmail.com', 'outlook.com', 'yahoo.com', 'bing.com', 'ebay.com',
    'dropbox.com', 'spotify.com', 'twitch.tv', 'discord.com', 'slack.com'
];

function checkHomoglyphAttack(hostname) {
    const domain = hostname.toLowerCase();

    // Check for non-ASCII characters
    let hasSuspiciousChars = false;
    let suspiciousChars = [];

    for (let char of domain) {
        if (char.charCodeAt(0) > 127) {
            hasSuspiciousChars = true;
            suspiciousChars.push({
                char: char,
                code: 'U+' + char.charCodeAt(0).toString(16).toUpperCase(),
                lookalike: homoglyphMappings[char] || '?'
            });
        }
    }

    // IMPORTANT: Only block if there are suspicious characters
    // Don't block normal domains
    if (!hasSuspiciousChars) {
        return {
            isSuspicious: false,
            hasSuspiciousChars: false,
            suspiciousChars: [],
            normalizedDomain: domain,
            isImpersonating: false,
            mixedScripts: false,
            originalDomain: domain
        };
    }

    // Normalize domain by replacing homoglyphs
    let normalizedDomain = domain;
    for (let [fake, real] of Object.entries(homoglyphMappings)) {
        normalizedDomain = normalizedDomain.split(fake).join(real);
    }

    // Check if normalized domain matches a legitimate one
    const isImpersonating = legitimateDomains.some(legit => {
        // Extract main domain (remove subdomains)
        const mainDomain = normalizedDomain.split('.').slice(-2).join('.');
        return mainDomain === legit || normalizedDomain === legit;
    });

    // Check for mixed scripts
    const hasLatin = /[a-z]/i.test(domain);
    const hasCyrillic = /[а-яА-Я]/.test(domain);
    const hasGreek = /[α-ωΑ-Ω]/.test(domain);
    const mixedScripts = [hasLatin, hasCyrillic, hasGreek].filter(Boolean).length > 1;

    // CRITICAL FIX: Only block if BOTH conditions are true:
    // 1. Has suspicious characters (non-ASCII)
    // 2. Is trying to impersonate a known legitimate domain
    const shouldBlock = hasSuspiciousChars && isImpersonating;

    return {
        isSuspicious: shouldBlock,
        hasSuspiciousChars,
        suspiciousChars,
        normalizedDomain,
        isImpersonating,
        mixedScripts,
        originalDomain: domain
    };
}

// Initialize extension on install
chrome.runtime.onInstalled.addListener(() => {
    console.log('b1swa installed');

    // Initialize storage with default settings
    chrome.storage.local.set({
        adBlockerEnabled: true,
        adultFilterEnabled: true,
        httpsEnforcementEnabled: true,
        malwareProtectionEnabled: true,
        stats: {
            adsBlocked: 0,
            trackersBlocked: 0,
            maliciousBlocked: 0,
            adultBlocked: 0,
            httpsUpgraded: 0,
            totalBlocked: 0
        },
        startDate: Date.now()
    });
});

// Statistics tracking
let stats = {
    adsBlocked: 0,
    trackersBlocked: 0,
    maliciousBlocked: 0,
    adultBlocked: 0,
    httpsUpgraded: 0,
    totalBlocked: 0
};

// Load stats from storage
chrome.storage.local.get(['stats'], (result) => {
    if (result.stats) {
        stats = result.stats;
    }
});

// Save stats periodically
function saveStats() {
    chrome.storage.local.set({ stats });
}

// Update stats every 30 seconds
chrome.alarms.create('saveStats', { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === 'saveStats') {
        saveStats();
    }
});

// Listen for web navigation to check URLs
chrome.webNavigation.onBeforeNavigate.addListener((details) => {
    if (details.frameId === 0) { // Main frame only
        try {
            const url = new URL(details.url);
            const hostname = url.hostname;

            // Check for homoglyph attacks
            const homoglyphCheck = checkHomoglyphAttack(hostname);

            if (homoglyphCheck.isSuspicious) {
                // Show browser notification
                chrome.notifications.create({
                    type: 'basic',
                    iconUrl: 'icons/icon128.png',
                    title: '🚨 Phishing Attack Blocked!',
                    message: `Homoglyph attack detected: ${hostname}`,
                    priority: 2
                });

                // Log the detection
                chrome.storage.local.get(['homoglyphLog'], (result) => {
                    const log = result.homoglyphLog || [];
                    log.unshift({
                        domain: hostname,
                        normalized: homoglyphCheck.normalizedDomain,
                        timestamp: Date.now(),
                        suspiciousChars: homoglyphCheck.suspiciousChars.length
                    });

                    // Keep only last 50 detections
                    if (log.length > 50) log.pop();

                    chrome.storage.local.set({ homoglyphLog: log });
                });

                // Block and redirect to warning page
                chrome.tabs.update(details.tabId, {
                    url: chrome.runtime.getURL('blocked.html') +
                        '?reason=homoglyph' +
                        '&domain=' + encodeURIComponent(hostname) +
                        '&normalized=' + encodeURIComponent(homoglyphCheck.normalizedDomain) +
                        '&original=' + encodeURIComponent(details.url)
                });

                stats.maliciousBlocked++;
                stats.totalBlocked++;
                chrome.storage.local.set({ stats });
                return;
            }

            // Continue with other security checks
            checkUrlSafety(details.url, details.tabId);
        } catch (e) {
            console.log('URL check error:', e);
        }
    }
});

// Check URL safety
async function checkUrlSafety(url, tabId) {
    const settings = await chrome.storage.local.get([
        'adultFilterEnabled',
        'malwareProtectionEnabled',
        'httpsEnforcementEnabled'
    ]);

    // Adult content detection
    if (settings.adultFilterEnabled && isAdultContent(url)) {
        stats.adultBlocked++;
        stats.totalBlocked++;
        blockPage(tabId, 'adult');
        return;
    }

    // Malware detection
    if (settings.malwareProtectionEnabled && isMalicious(url)) {
        stats.maliciousBlocked++;
        stats.totalBlocked++;
        blockPage(tabId, 'malware');
        return;
    }

    // HTTPS enforcement
    if (settings.httpsEnforcementEnabled && url.startsWith('http://')) {
        const httpsUrl = url.replace('http://', 'https://');
        chrome.tabs.update(tabId, { url: httpsUrl });
        stats.httpsUpgraded++;
    }
}

// Adult content detection (basic pattern matching)
function isAdultContent(url) {
    const adultPatterns = [
        'porn', 'xxx', 'adult', 'sex', 'nsfw', 'xvideos', 'pornhub',
        'xhamster', 'redtube', 'youporn', 'tube8', 'spankwire'
    ];

    const urlLower = url.toLowerCase();
    return adultPatterns.some(pattern => urlLower.includes(pattern));
}

// Malicious site detection (basic pattern matching)
function isMalicious(url) {
    const maliciousPatterns = [
        'phishing', 'malware', 'virus', 'scam', 'fake-download',
        'free-iphone', 'you-won', 'claim-prize'
    ];

    const urlLower = url.toLowerCase();
    return maliciousPatterns.some(pattern => urlLower.includes(pattern));
}

// Block page with warning
function blockPage(tabId, reason) {
    const blockPageUrl = chrome.runtime.getURL(`blocked.html?reason=${reason}`);
    chrome.tabs.update(tabId, { url: blockPageUrl });
}

// Listen for messages from content scripts
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'getStats') {
        sendResponse({ stats });
    } else if (request.action === 'adBlocked') {
        stats.adsBlocked++;
        stats.totalBlocked++;
    } else if (request.action === 'trackerBlocked') {
        stats.trackersBlocked++;
        stats.totalBlocked++;
    } else if (request.action === 'getSettings') {
        chrome.storage.local.get([
            'adBlockerEnabled',
            'adultFilterEnabled',
            'httpsEnforcementEnabled',
            'malwareProtectionEnabled'
        ], (settings) => {
            sendResponse(settings);
        });
        return true; // Keep channel open for async response
    }
});

// Network activity monitoring for dashboard
let networkActivity = [];
const MAX_ACTIVITY_ENTRIES = 100;

chrome.webRequest.onCompleted.addListener(
    (details) => {
        networkActivity.push({
            url: details.url,
            timestamp: Date.now(),
            type: details.type,
            statusCode: details.statusCode
        });

        // Keep only recent entries
        if (networkActivity.length > MAX_ACTIVITY_ENTRIES) {
            networkActivity.shift();
        }
    },
    { urls: ["<all_urls>"] }
);

// Provide network activity to dashboard
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'getNetworkActivity') {
        sendResponse({ activity: networkActivity.slice(-20) });
    }
});

console.log('b1swa background worker loaded');
