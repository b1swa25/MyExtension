// b1swa - Content Blocker
// Runs on all pages to block ads and trackers at DOM level

(function () {
    'use strict';

    // Ad selectors to remove
    const adSelectors = [
        'iframe[src*="doubleclick"]',
        'iframe[src*="googlesyndication"]',
        'iframe[src*="googleadservices"]',
        'div[id*="google_ads"]',
        'div[class*="advertisement"]',
        'div[class*="ad-container"]',
        'div[class*="ad-banner"]',
        'div[id*="ad-"]',
        'div[class*="sponsored"]',
        'ins.adsbygoogle',
        '[data-ad-slot]',
        '[data-ad-client]'
    ];

    // Tracker selectors
    const trackerSelectors = [
        'script[src*="google-analytics"]',
        'script[src*="facebook.com/tr"]',
        'script[src*="hotjar"]',
        'script[src*="scorecardresearch"]',
        'img[src*="facebook.com/tr"]'
    ];

    // Remove ads from DOM
    function removeAds() {
        let adsRemoved = 0;

        adSelectors.forEach(selector => {
            const elements = document.querySelectorAll(selector);
            elements.forEach(el => {
                el.remove();
                adsRemoved++;
            });
        });

        if (adsRemoved > 0) {
            chrome.runtime.sendMessage({ action: 'adBlocked' });
        }
    }

    // Remove trackers from DOM
    function removeTrackers() {
        let trackersRemoved = 0;

        trackerSelectors.forEach(selector => {
            const elements = document.querySelectorAll(selector);
            elements.forEach(el => {
                el.remove();
                trackersRemoved++;
            });
        });

        if (trackersRemoved > 0) {
            chrome.runtime.sendMessage({ action: 'trackerBlocked' });
        }
    }

    // Clean page
    function cleanPage() {
        removeAds();
        removeTrackers();
    }

    // Run on page load
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', cleanPage);
    } else {
        cleanPage();
    }

    // Watch for dynamically added ads
    const observer = new MutationObserver((mutations) => {
        cleanPage();
    });

    observer.observe(document.documentElement, {
        childList: true,
        subtree: true
    });

    // Clean up after 5 seconds (catch lazy-loaded ads)
    setTimeout(cleanPage, 5000);

})();
