// b1swa Dashboard - Interactive New Tab
// Handles all dashboard widgets and real-time updates

// ===== ANIMATED DIGITAL DATA RAIN (MATRIX STYLE) =====
const canvas = document.getElementById('particleCanvas');
canvas.style.position = 'fixed';
canvas.style.top = '0';
canvas.style.left = '0';
canvas.style.zIndex = '-1'; // Between image (-2) and content (10)
canvas.style.pointerEvents = 'none';
const ctx = canvas.getContext('2d');

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

const katakana = '01'; // Binary data flow
const latin = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
const nums = '0123456789';
const alphabet = katakana + latin + nums;

const fontSize = 14;
const columns = canvas.width / fontSize;

const rainDrops = [];

for (let x = 0; x < columns; x++) {
    rainDrops[x] = 1;
}

function drawMatrix() {
    // Semi-transparent black rectangle to create trail effect
    ctx.fillStyle = 'rgba(10, 10, 10, 0.05)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.fillStyle = '#0F0'; // Neon Green
    ctx.font = fontSize + 'px monospace';

    for (let i = 0; i < rainDrops.length; i++) {
        const text = katakana.charAt(Math.floor(Math.random() * katakana.length));
        ctx.fillText(text, i * fontSize, rainDrops[i] * fontSize);

        if (rainDrops[i] * fontSize > canvas.height && Math.random() > 0.975) {
            rainDrops[i] = 0;
        }
        rainDrops[i]++;
    }
}

let animationId = setInterval(drawMatrix, 30);

// Resize canvas on window resize
window.addEventListener('resize', () => {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    const newColumns = canvas.width / fontSize;
    for (let x = rainDrops.length; x < newColumns; x++) {
        rainDrops[x] = 1;
    }
});

// ===== CLOCK WIDGET =====
function updateClock() {
    const now = new Date();
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');

    document.getElementById('clock').textContent = `${hours}:${minutes}:${seconds}`;

    const days = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
    const months = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
    const dateStr = `${days[now.getDay()]} ${months[now.getMonth()]} ${now.getDate()}, ${now.getFullYear()}`;

    document.getElementById('date').textContent = dateStr;
}

// Update clock every second
setInterval(updateClock, 1000);
updateClock();

// ===== SEARCH FUNCTIONALITY =====
document.getElementById('searchBtn').addEventListener('click', performSearch);
document.getElementById('searchInput').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') performSearch();
});

function performSearch() {
    const query = document.getElementById('searchInput').value;
    if (query.trim()) {
        window.location.href = `https://www.google.com/search?q=${encodeURIComponent(query)}`;
    }
}

// ===== HTOP SYSTEM MONITOR =====
const processes = [
    { pid: 1337, user: 'root', cpu: 0, mem: 0, cmd: 'chrome --type=browser' },
    { pid: 3141, user: 'root', cpu: 0, mem: 0, cmd: 'b1swa-cybersec-daemon' },
    { pid: 4096, user: 'root', cpu: 0, mem: 0, cmd: 'firewall-monitor' },
    { pid: 5555, user: 'root', cpu: 0, mem: 0, cmd: 'threat-scanner' },
    { pid: 8888, user: 'root', cpu: 0, mem: 0, cmd: 'ad-blocker-engine' },
    { pid: 9999, user: 'root', cpu: 0, mem: 0, cmd: 'malware-detector' }
];

function updateHtop() {
    const htopDisplay = document.getElementById('htopDisplay');
    let output = '  PID USER      CPU%  MEM%  COMMAND\n';
    output += '─'.repeat(60) + '\n';

    processes.forEach(proc => {
        // Randomize CPU and MEM for realistic effect
        proc.cpu = (Math.random() * 15).toFixed(1);
        proc.mem = (Math.random() * 8).toFixed(1);

        const line = `${String(proc.pid).padStart(5)} ${proc.user.padEnd(9)} ${String(proc.cpu).padStart(5)} ${String(proc.mem).padStart(5)}  ${proc.cmd}\n`;
        output += line;
    });

    htopDisplay.innerHTML = output.split('\n').map(line =>
        `<div class="htop-line">${line}</div>`
    ).join('');
}

// Update htop and resource bars every 2 seconds
function updateSystemMetrics() {
    updateHtop();

    // Update resource bars with random movement for realism
    const cpu = Math.floor(Math.random() * 15) + 5;
    const mem = Math.floor(Math.random() * 8) + 12;
    const net = Math.floor(Math.random() * 200) + 50;

    document.getElementById('cpuBar').style.width = cpu + '%';
    document.getElementById('cpuText').textContent = cpu + '%';

    document.getElementById('memBar').style.width = mem + '%';
    document.getElementById('memText').textContent = mem + '%';

    document.getElementById('netBar').style.width = Math.min(net / 10, 100) + '%';
    document.getElementById('netText').textContent = net + ' KB/s';
}

setInterval(updateSystemMetrics, 2000);
updateSystemMetrics();

// ===== RESOURCE BARS =====
let cpuUsage = 0;
let memUsage = 0;
let netUsage = 0;

function updateResourceBars() {
    // Simulate realistic fluctuations
    cpuUsage = Math.max(10, Math.min(95, cpuUsage + (Math.random() - 0.5) * 20));
    memUsage = Math.max(20, Math.min(80, memUsage + (Math.random() - 0.5) * 15));
    netUsage = Math.max(0, Math.min(1000, netUsage + (Math.random() - 0.5) * 200));

    document.getElementById('cpuBar').style.width = cpuUsage + '%';
    document.getElementById('cpuText').textContent = cpuUsage.toFixed(1) + '%';

    document.getElementById('memBar').style.width = memUsage + '%';
    document.getElementById('memText').textContent = memUsage.toFixed(1) + '%';

    document.getElementById('netBar').style.width = (netUsage / 10) + '%';
    document.getElementById('netText').textContent = netUsage.toFixed(0) + ' KB/s';
}

// Update resource bars every second
setInterval(updateResourceBars, 1000);
updateResourceBars();

// ===== CYBER NEWS FEED =====
let newsCache = [];

// RSS feeds for cybersecurity news
const newsFeeds = [
    'https://feeds.feedburner.com/TheHackersNews',
    'https://www.bleepingcomputer.com/feed/',
    'https://threatpost.com/feed/',
    'https://www.darkreading.com/rss.xml'
];

// Fetch live news from RSS feeds
async function fetchLiveNews() {
    try {
        // Use RSS2JSON API to convert RSS to JSON
        const feedUrl = newsFeeds[Math.floor(Math.random() * newsFeeds.length)];
        const apiUrl = `https://api.rss2json.com/v1/api.json?rss_url=${encodeURIComponent(feedUrl)}`;

        const response = await fetch(apiUrl);
        const data = await response.json();

        if (data.status === 'ok' && data.items) {
            newsCache = data.items.slice(0, 10).map(item => ({
                title: item.title,
                link: item.link,
                source: new URL(item.link).hostname.replace('www.', ''),
                pubDate: item.pubDate
            }));
            updateNewsFeed();
        }
    } catch (error) {
        console.log('Failed to fetch live news, using cache');
        // Fallback to static news if fetch fails
        if (newsCache.length === 0) {
            newsCache = [
                {
                    title: "Critical Zero-Day Vulnerability Found in Popular VPN Software",
                    link: "https://www.bleepingcomputer.com",
                    source: "bleepingcomputer.com"
                },
                {
                    title: "Ransomware Group Targets Healthcare Sector with New Tactics",
                    link: "https://www.securityweek.com",
                    source: "securityweek.com"
                },
                {
                    title: "AI-Powered Phishing Attacks Increase by 300%",
                    link: "https://www.darkreading.com",
                    source: "darkreading.com"
                }
            ];
        }
    }
}

function updateNewsFeed() {
    const threatFeed = document.getElementById('threatFeed');
    threatFeed.innerHTML = '';

    if (newsCache.length === 0) {
        threatFeed.innerHTML = '<div class="threat-item"><div class="threat-title">Loading news...</div></div>';
        return;
    }

    // Show 2 random news items
    const shuffled = [...newsCache].sort(() => 0.5 - Math.random());
    const selected = shuffled.slice(0, 2);

    selected.forEach(item => {
        const div = document.createElement('div');
        div.className = 'threat-item';
        div.innerHTML = `
      <div class="threat-title">${item.title}</div>
      <div class="threat-meta">(${item.source})</div>
    `;

        // Make news item clickable
        div.addEventListener('click', () => {
            window.open(item.link, '_blank');
        });

        threatFeed.appendChild(div);
    });
}

// Fetch news on load and every 5 minutes
fetchLiveNews();
setInterval(fetchLiveNews, 5 * 60 * 1000);

// Rotate displayed news every 30 seconds
setInterval(updateNewsFeed, 30000);

// ===== NETWORK ACTIVITY CHART =====
function drawTrendChart() {
    const canvas = document.getElementById('trendChart');
    const ctx = canvas.getContext('2d');

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Generate random trend data
    const points = 20;
    const data = [];
    for (let i = 0; i < points; i++) {
        data.push(30 + Math.random() * 60);
    }

    // Draw grid
    ctx.strokeStyle = '#00FF4122';
    ctx.lineWidth = 1;
    for (let i = 0; i < 5; i++) {
        const y = (canvas.height / 4) * i;
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(canvas.width, y);
        ctx.stroke();
    }

    // Draw trend line
    ctx.strokeStyle = '#00FF41';
    ctx.lineWidth = 2;
    ctx.beginPath();

    const stepX = canvas.width / (points - 1);
    data.forEach((value, index) => {
        const x = index * stepX;
        const y = canvas.height - (value / 100 * canvas.height);

        if (index === 0) {
            ctx.moveTo(x, y);
        } else {
            ctx.lineTo(x, y);
        }
    });

    ctx.stroke();

    // Add glow effect
    ctx.shadowBlur = 10;
    ctx.shadowColor = '#00FF41';
    ctx.stroke();
}

// Update chart every 5 seconds
setInterval(drawTrendChart, 5000);
drawTrendChart();

// ===== NETWORK ACTIVITY BARS =====
function updateNetworkActivity() {
    const container = document.getElementById('networkActivity');
    container.innerHTML = '';

    const activities = ['DNS', 'HTTP', 'HTTPS', 'WebSocket'];

    activities.forEach(activity => {
        const div = document.createElement('div');
        div.className = 'activity-bar';

        const graph = document.createElement('div');
        graph.className = 'activity-graph';

        // Generate 10 random bars
        for (let i = 0; i < 10; i++) {
            const bar = document.createElement('div');
            bar.className = 'bar';
            bar.style.height = (Math.random() * 15 + 5) + 'px';
            graph.appendChild(bar);
        }

        div.innerHTML = `<span class="activity-label">${activity}</span>`;
        div.appendChild(graph);
        container.appendChild(div);
    });
}

// Update network activity every 3 seconds
setInterval(updateNetworkActivity, 3000);
updateNetworkActivity();

// ===== HOMOGLYPH ALERTS DISPLAY =====
function updateHomoglyphAlerts() {
    chrome.storage.local.get(['homoglyphLog'], (result) => {
        const log = result.homoglyphLog || [];
        const container = document.getElementById('homoglyphAlerts');

        if (log.length === 0) {
            container.innerHTML = `
                <div class="threat-item">
                    <div class="threat-title">No attacks detected</div>
                    <div class="threat-meta">System monitoring active</div>
                </div>
            `;
            return;
        }

        container.innerHTML = '';

        // Show last 3 detections
        log.slice(0, 3).forEach(detection => {
            const timeAgo = getTimeAgo(detection.timestamp);
            const div = document.createElement('div');
            div.className = 'threat-item';
            div.style.cursor = 'pointer';
            div.style.borderLeft = '3px solid #FF4141';

            div.innerHTML = `
                <div class="threat-title" style="color: #FF4141;">
                    🚨 ${detection.domain}
                </div>
                <div class="threat-meta">
                    Blocked ${timeAgo} • ${detection.suspiciousChars} suspicious chars
                </div>
            `;

            container.appendChild(div);
        });
    });
}

function getTimeAgo(timestamp) {
    const seconds = Math.floor((Date.now() - timestamp) / 1000);
    if (seconds < 60) return 'just now';
    if (seconds < 3600) return Math.floor(seconds / 60) + 'm ago';
    if (seconds < 86400) return Math.floor(seconds / 3600) + 'h ago';
    return Math.floor(seconds / 86400) + 'd ago';
}

// Update homoglyph alerts every 5 seconds
setInterval(updateHomoglyphAlerts, 5000);
updateHomoglyphAlerts();

// ===== STATISTICS FROM BACKGROUND =====
function updateStats() {
    chrome.runtime.sendMessage({ action: 'getStats' }, (response) => {
        if (response && response.stats) {
            document.getElementById('adsBlocked').textContent = response.stats.adsBlocked;
            document.getElementById('trackersBlocked').textContent = response.stats.trackersBlocked;
            document.getElementById('threatsBlocked').textContent =
                response.stats.maliciousBlocked + response.stats.adultBlocked;
            document.getElementById('httpsUpgraded').textContent = response.stats.httpsUpgraded;
        }
    });
}

// Update stats every 5 seconds
setInterval(updateStats, 5000);
updateStats();

// ===== MODAL CONTROLS =====
function openModal(modalId) {
    document.getElementById(modalId).classList.add('active');

    // Load data when opening specific modals
    if (modalId === 'protectModal') {
        loadProtectionSettings();
    } else if (modalId === 'firewallModal') {
        loadFirewallData();
    }
}

function closeModal(modalId) {
    document.getElementById(modalId).classList.remove('active');
}

// Setup close button listeners
setTimeout(() => {
    document.querySelectorAll('.modal-close').forEach(button => {
        button.addEventListener('click', function (e) {
            e.stopPropagation();
            const modalId = this.getAttribute('data-modal');
            if (modalId) {
                closeModal(modalId);
            }
        });
    });
}, 100);

// Close modal when clicking outside
document.addEventListener('click', (e) => {
    if (e.target.classList.contains('tool-modal')) {
        e.target.classList.remove('active');
    }
});

// ===== HOMOGLYPH ATTACK CHECKER =====
function checkHomoglyph() {
    const domain = document.getElementById('homoglyphInput').value.trim().toLowerCase();
    const resultDiv = document.getElementById('homoglyphResult');

    if (!domain) {
        resultDiv.innerHTML = '<div style="color: #FF4141;">Please enter a domain name</div>';
        return;
    }

    resultDiv.innerHTML = '<div style="color: #00FF41;">🔤 Analyzing domain for homoglyph attacks...</div>';

    // Common homoglyph mappings (lookalike characters)
    const homoglyphs = {
        // Cyrillic lookalikes
        'а': 'a', 'е': 'e', 'о': 'o', 'р': 'p', 'с': 'c', 'у': 'y', 'х': 'x',
        // Greek lookalikes
        'α': 'a', 'β': 'b', 'ε': 'e', 'ι': 'i', 'ο': 'o', 'ρ': 'p', 'τ': 't', 'υ': 'y',
        // Other confusables
        '0': 'o', '1': 'l', '3': 'e', '5': 's', '8': 'b',
        'ı': 'i', 'ǀ': 'l', '‐': '-', '‑': '-', '‒': '-'
    };

    // Known legitimate domains to check against
    const legitimateDomains = [
        'google.com', 'facebook.com', 'amazon.com', 'microsoft.com', 'apple.com',
        'twitter.com', 'instagram.com', 'linkedin.com', 'github.com', 'youtube.com',
        'paypal.com', 'netflix.com', 'reddit.com', 'wikipedia.org', 'stackoverflow.com'
    ];

    setTimeout(() => {
        let html = '';
        let suspiciousChars = [];
        let warnings = [];

        // Check for non-ASCII characters
        for (let char of domain) {
            if (char.charCodeAt(0) > 127) {
                suspiciousChars.push({
                    char: char,
                    code: char.charCodeAt(0).toString(16).toUpperCase(),
                    lookalike: homoglyphs[char] || '?'
                });
            }
        }

        // Normalize domain by replacing homoglyphs
        let normalizedDomain = domain;
        for (let [fake, real] of Object.entries(homoglyphs)) {
            normalizedDomain = normalizedDomain.split(fake).join(real);
        }

        // Check if normalized domain matches a legitimate one
        const isImpersonating = legitimateDomains.some(legit =>
            normalizedDomain === legit || normalizedDomain.includes(legit)
        );

        // Check for mixed scripts
        const hasLatin = /[a-z]/.test(domain);
        const hasCyrillic = /[а-я]/.test(domain);
        const hasGreek = /[α-ω]/.test(domain);
        const mixedScripts = [hasLatin, hasCyrillic, hasGreek].filter(Boolean).length > 1;

        // Generate report
        if (suspiciousChars.length === 0 && !mixedScripts) {
            html = `
                <div style="color: #00FF41; margin-bottom: 10px;">✅ Domain appears safe!</div>
                <div><strong>Domain:</strong> ${domain}</div>
                <div style="color: #64FF64; margin-top: 10px;">
                    ✓ No suspicious characters detected<br>
                    ✓ Uses standard ASCII characters<br>
                    ✓ No homoglyph attacks found
                </div>
            `;
        } else {
            html = `<div style="color: #FF4141; margin-bottom: 10px;">⚠️ SUSPICIOUS DOMAIN DETECTED!</div>`;
            html += `<div><strong>Original:</strong> ${domain}</div>`;
            html += `<div><strong>Normalized:</strong> ${normalizedDomain}</div>`;

            if (suspiciousChars.length > 0) {
                html += `<div style="margin-top: 10px;"><strong>Suspicious Characters:</strong></div>`;
                suspiciousChars.forEach(({ char, code, lookalike }) => {
                    html += `<div style="color: #FF4141; margin-left: 10px;">
                        → '${char}' (U+${code}) looks like '${lookalike}'
                    </div>`;
                });
            }

            if (mixedScripts) {
                html += `<div style="color: #FF4141; margin-top: 10px;">
                    ⚠️ Mixed character scripts detected (potential IDN spoofing)
                </div>`;
            }

            if (isImpersonating) {
                html += `<div style="color: #FF4141; margin-top: 10px;">
                    🚨 POSSIBLE IMPERSONATION ATTACK!<br>
                    This domain may be impersonating: ${normalizedDomain}
                </div>`;
            }

            html += `<div style="margin-top: 10px; color: #888; font-size: 11px;">
                ⚠️ This domain uses lookalike characters and may be a phishing attempt.
            </div>`;
        }

        resultDiv.innerHTML = html;
    }, 1500);
}

// ===== URL SAFETY CHECKER =====
function checkUrlSafety() {
    const url = document.getElementById('urlInput').value.trim();
    const resultDiv = document.getElementById('urlResult');

    if (!url) {
        resultDiv.innerHTML = '<div style="color: #FF4141;">Please enter a URL</div>';
        return;
    }

    resultDiv.innerHTML = '<div style="color: #00FF41;">🔗 Analyzing URL safety...</div>';

    setTimeout(() => {
        let html = '';
        let warnings = [];
        let score = 100;

        try {
            const urlObj = new URL(url);

            // Check 1: HTTPS
            if (urlObj.protocol !== 'https:') {
                warnings.push('⚠️ Not using HTTPS (insecure connection)');
                score -= 30;
            }

            // Check 2: IP address instead of domain
            if (/^\d+\.\d+\.\d+\.\d+$/.test(urlObj.hostname)) {
                warnings.push('⚠️ Uses IP address instead of domain name');
                score -= 20;
            }

            // Check 3: Suspicious TLDs
            const suspiciousTlds = ['.tk', '.ml', '.ga', '.cf', '.gq', '.xyz', '.top'];
            if (suspiciousTlds.some(tld => urlObj.hostname.endsWith(tld))) {
                warnings.push('⚠️ Uses suspicious top-level domain');
                score -= 15;
            }

            // Check 4: Excessive subdomains
            const subdomains = urlObj.hostname.split('.');
            if (subdomains.length > 4) {
                warnings.push('⚠️ Excessive subdomains (possible phishing)');
                score -= 15;
            }

            // Check 5: Suspicious keywords
            const suspiciousKeywords = ['login', 'verify', 'account', 'secure', 'update', 'confirm', 'banking'];
            const hasSuspiciousKeyword = suspiciousKeywords.some(kw =>
                urlObj.hostname.includes(kw) || urlObj.pathname.includes(kw)
            );
            if (hasSuspiciousKeyword) {
                warnings.push('⚠️ Contains suspicious keywords (login, verify, etc.)');
                score -= 10;
            }

            // Check 6: Port number
            if (urlObj.port && urlObj.port !== '80' && urlObj.port !== '443') {
                warnings.push(`⚠️ Non-standard port: ${urlObj.port}`);
                score -= 10;
            }

            // Check 7: @ symbol (credential phishing)
            if (url.includes('@')) {
                warnings.push('🚨 Contains @ symbol (credential phishing attempt)');
                score -= 40;
            }

            // Generate report
            const safetyLevel = score >= 80 ? '🟢 SAFE' : score >= 50 ? '🟡 SUSPICIOUS' : '🔴 DANGEROUS';
            const color = score >= 80 ? '#00FF41' : score >= 50 ? '#FFD700' : '#FF4141';

            html = `
                <div style="color: ${color}; margin-bottom: 10px; font-size: 14px;">
                    ${safetyLevel} (Safety Score: ${score}/100)
                </div>
                <div><strong>URL:</strong> ${url}</div>
                <div><strong>Protocol:</strong> ${urlObj.protocol}</div>
                <div><strong>Domain:</strong> ${urlObj.hostname}</div>
            `;

            if (warnings.length > 0) {
                html += `<div style="margin-top: 10px;"><strong>Warnings:</strong></div>`;
                warnings.forEach(warning => {
                    html += `<div style="color: #FF4141; margin-left: 10px;">${warning}</div>`;
                });
            } else {
                html += `<div style="color: #64FF64; margin-top: 10px;">
                    ✓ No suspicious patterns detected<br>
                    ✓ URL appears legitimate
                </div>`;
            }

        } catch (e) {
            html = `<div style="color: #FF4141;">❌ Invalid URL format</div>`;
        }

        resultDiv.innerHTML = html;
    }, 1500);
}

// ===== ENCRYPT TOOL =====
function encryptText() {
    const input = document.getElementById('encryptInput').value;
    const key = document.getElementById('encryptKey').value || 'b1swa-default-key';

    if (!input) {
        document.getElementById('encryptOutput').value = 'Please enter text to encrypt';
        return;
    }

    // Simple Base64 + XOR encryption
    const encrypted = btoa(xorEncrypt(input, key));
    document.getElementById('encryptOutput').value = encrypted;
}

function decryptText() {
    const input = document.getElementById('encryptInput').value;
    const key = document.getElementById('encryptKey').value || 'b1swa-default-key';

    if (!input) {
        document.getElementById('encryptOutput').value = 'Please enter text to decrypt';
        return;
    }

    try {
        const decrypted = xorEncrypt(atob(input), key);
        document.getElementById('encryptOutput').value = decrypted;
    } catch (e) {
        document.getElementById('encryptOutput').value = 'Invalid encrypted text';
    }
}

function xorEncrypt(text, key) {
    let result = '';
    for (let i = 0; i < text.length; i++) {
        result += String.fromCharCode(text.charCodeAt(i) ^ key.charCodeAt(i % key.length));
    }
    return result;
}

function copyEncryptResult() {
    const output = document.getElementById('encryptOutput');
    output.select();
    document.execCommand('copy');
    alert('Copied to clipboard!');
}

// ===== SCAN TOOL =====
function loadScanData() {
    chrome.runtime.sendMessage({ action: 'getStats' }, (response) => {
        if (response && response.stats) {
            document.getElementById('scanAds').textContent = response.stats.adsBlocked;
            document.getElementById('scanTrackers').textContent = response.stats.trackersBlocked;
            document.getElementById('scanThreats').textContent =
                response.stats.maliciousBlocked + response.stats.adultBlocked;
            document.getElementById('scanHttps').textContent = response.stats.httpsUpgraded;
        }
    });
}

function runQuickScan() {
    const resultDiv = document.getElementById('scanResult');
    resultDiv.innerHTML = '<div style="color: #00FF41;">⏳ Scanning...</div>';

    setTimeout(() => {
        chrome.runtime.sendMessage({ action: 'getStats' }, (response) => {
            if (response && response.stats) {
                const total = response.stats.totalBlocked;
                const status = total > 100 ? '🛡️ EXCELLENT' : total > 50 ? '✅ GOOD' : '⚠️ MODERATE';

                resultDiv.innerHTML = `
          <div style="color: #00FF41; margin-bottom: 10px;">✅ Scan Complete!</div>
          <div>Protection Status: ${status}</div>
          <div>Total Threats Blocked: ${total}</div>
          <div>Last Scan: ${new Date().toLocaleTimeString()}</div>
          <div style="margin-top: 10px; color: #64FF64;">
            Your browser is actively protected by b1swa.
          </div>
        `;
            }
        });
    }, 2000);
}

// ===== PROTECT TOOL =====
function loadProtectionSettings() {
    chrome.storage.local.get([
        'adBlockerEnabled',
        'adultFilterEnabled',
        'httpsEnforcementEnabled',
        'malwareProtectionEnabled'
    ], (settings) => {
        document.getElementById('protectAdBlocker').checked = settings.adBlockerEnabled !== false;
        document.getElementById('protectAdultFilter').checked = settings.adultFilterEnabled !== false;
        document.getElementById('protectHttps').checked = settings.httpsEnforcementEnabled !== false;
        document.getElementById('protectMalware').checked = settings.malwareProtectionEnabled !== false;
    });
}

function toggleProtection(setting, enabled) {
    console.log('toggleProtection called:', setting, enabled);
    const obj = {};
    obj[setting] = enabled;
    chrome.storage.local.set(obj);
}

function enableAllProtection() {
    console.log('enableAllProtection called');
    chrome.storage.local.set({
        adBlockerEnabled: true,
        adultFilterEnabled: true,
        httpsEnforcementEnabled: true,
        malwareProtectionEnabled: true
    }, () => {
        console.log('All protection enabled');
        loadProtectionSettings();
    });
}

function disableAllProtection() {
    console.log('disableAllProtection called');
    chrome.storage.local.set({
        adBlockerEnabled: false,
        adultFilterEnabled: false,
        httpsEnforcementEnabled: false,
        malwareProtectionEnabled: false
    }, () => {
        console.log('All protection disabled');
        loadProtectionSettings();
    });
}

// ===== FIREWALL TOOL =====
let firewallLog = [];

function loadFirewallData() {
    chrome.runtime.sendMessage({ action: 'getStats' }, (response) => {
        if (response && response.stats) {
            document.getElementById('firewallBlocked').textContent = response.stats.totalBlocked;
            document.getElementById('firewallAllowed').textContent = Math.floor(Math.random() * 1000) + 500;

            // Simulate recent blocked requests
            if (firewallLog.length === 0) {
                firewallLog = [
                    { url: 'doubleclick.net/ad.js', time: new Date().toLocaleTimeString(), type: 'blocked' },
                    { url: 'googlesyndication.com/ads', time: new Date().toLocaleTimeString(), type: 'blocked' },
                    { url: 'facebook.com/tr', time: new Date().toLocaleTimeString(), type: 'blocked' }
                ];
            }

            updateFirewallLog();
        }
    });
}

function updateFirewallLog() {
    const logDiv = document.getElementById('firewallLog');

    if (logDiv) { // Added check for logDiv existence
        if (firewallLog.length === 0) {
            logDiv.innerHTML = '<div class="log-entry">No blocked requests yet...</div>';
            return;
        }

        logDiv.innerHTML = firewallLog.slice(-10).reverse().map(entry =>
            `<div class="log-entry ${entry.type}">[${entry.time}] Blocked: ${entry.url}</div>`
        ).join('');
    }
}

function clearFirewallLog() {
    console.log('clearFirewallLog called');
    firewallLog = [];
    updateFirewallLog();
    console.log('Firewall log cleared');
}

// ===== LIVE SECURITY LOGS =====
const securityLogs = document.getElementById('securityLogs');
const logEvents = [
    { type: 'threat', msg: 'Ad blocked: doubleclick.net' },
    { type: 'threat', msg: 'Tracker prevented: facebook.com/tr' },
    { type: 'upgrade', msg: 'HTTPS upgrade: http://example.com' },
    { type: 'info', msg: 'System check: No vulnerabilities found' },
    { type: 'info', msg: 'Firewall rules updated' },
    { type: 'threat', msg: 'Malware signature detected and blocked' },
    { type: 'upgrade', msg: 'Connection secured: github.com' },
    { type: 'info', msg: 'Background scan completed' }
];

// Load logs from storage
function loadLogs() {
    if (!securityLogs) return;
    chrome.storage.local.get(['securityLogs'], (result) => {
        if (result.securityLogs && result.securityLogs.length > 0) {
            securityLogs.innerHTML = result.securityLogs.map(log =>
                `<div class="log-entry-item"><span style="color: #444;">[${log.time}]</span> <span class="log-type-${log.type}">${log.type.toUpperCase()}</span>: ${log.msg}</div>`
            ).join('');
            securityLogs.scrollTop = securityLogs.scrollHeight;
        }
    });
}

function addSecurityLog(customEvent = null) {
    if (!securityLogs) return;

    const event = customEvent || logEvents[Math.floor(Math.random() * logEvents.length)];
    const time = new Date().toLocaleTimeString([], { hour12: false });

    const logItem = document.createElement('div');
    logItem.className = 'log-entry-item';
    logItem.innerHTML = `<span style="color: #444;">[${time}]</span> <span class="log-type-${event.type}">${event.type.toUpperCase()}</span>: ${event.msg}`;

    securityLogs.appendChild(logItem);
    securityLogs.scrollTop = securityLogs.scrollHeight;

    if (securityLogs.children.length > 50) {
        securityLogs.removeChild(securityLogs.firstChild);
    }

    // Save to storage
    const logsToSave = Array.from(securityLogs.children).map(child => {
        const text = child.textContent;
        const timeMatch = text.match(/\[(.*?)\]/);
        const typeMatch = text.match(/ (THREAT|INFO|UPGRADE):/);
        const msg = text.split(': ')[1];
        return {
            time: timeMatch ? timeMatch[1] : '',
            type: typeMatch ? typeMatch[1].toLowerCase() : 'info',
            msg: msg
        };
    });
    chrome.storage.local.set({ securityLogs: logsToSave });
}

// Initial logs and setup
loadLogs();
setTimeout(() => {
    if (securityLogs && securityLogs.children.length === 0) {
        addSecurityLog({ type: 'info', msg: 'System monitoring initialized.' });
    }
    setInterval(addSecurityLog, 8000); // New random log every 8 seconds
}, 1000);

// Make all functions globally accessible
window.openModal = openModal;
window.closeModal = closeModal;
window.checkHomoglyph = checkHomoglyph;
window.checkUrlSafety = checkUrlSafety;
window.toggleProtection = toggleProtection;
window.enableAllProtection = enableAllProtection;
window.disableAllProtection = disableAllProtection;
window.clearFirewallLog = clearFirewallLog;

console.log('b1swa Dashboard loaded successfully');
