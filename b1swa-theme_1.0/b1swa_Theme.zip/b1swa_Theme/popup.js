// b1swa Popup - Control Panel
// Handles toggle switches and statistics display

// Load current settings
chrome.storage.local.get([
    'adBlockerEnabled',
    'adultFilterEnabled',
    'httpsEnforcementEnabled',
    'malwareProtectionEnabled'
], (settings) => {
    document.getElementById('toggleAdBlocker').checked = settings.adBlockerEnabled !== false;
    document.getElementById('toggleAdultFilter').checked = settings.adultFilterEnabled !== false;
    document.getElementById('toggleHttps').checked = settings.httpsEnforcementEnabled !== false;
    document.getElementById('toggleMalware').checked = settings.malwareProtectionEnabled !== false;
});

// Save settings when toggles change
document.getElementById('toggleAdBlocker').addEventListener('change', (e) => {
    chrome.storage.local.set({ adBlockerEnabled: e.target.checked });
});

document.getElementById('toggleAdultFilter').addEventListener('change', (e) => {
    chrome.storage.local.set({ adultFilterEnabled: e.target.checked });
});

document.getElementById('toggleHttps').addEventListener('change', (e) => {
    chrome.storage.local.set({ httpsEnforcementEnabled: e.target.checked });
});

document.getElementById('toggleMalware').addEventListener('change', (e) => {
    chrome.storage.local.set({ malwareProtectionEnabled: e.target.checked });
});

// Load and display statistics
function updateStats() {
    chrome.runtime.sendMessage({ action: 'getStats' }, (response) => {
        if (response && response.stats) {
            document.getElementById('popupAdsBlocked').textContent = response.stats.adsBlocked;
            document.getElementById('popupTrackersBlocked').textContent = response.stats.trackersBlocked;
            document.getElementById('popupThreatsBlocked').textContent =
                response.stats.maliciousBlocked + response.stats.adultBlocked;
            document.getElementById('popupHttpsUpgraded').textContent = response.stats.httpsUpgraded;
        }
    });
}

// Update stats on load and every 2 seconds
updateStats();
setInterval(updateStats, 2000);

// Dashboard button
document.getElementById('openDashboard').addEventListener('click', () => {
    chrome.tabs.create({ url: 'chrome://newtab' });
    window.close();
});

// Settings button
document.getElementById('openSettings').addEventListener('click', () => {
    chrome.tabs.create({ url: chrome.runtime.getURL('settings.html') });
    window.close();
});

console.log('b1swa popup loaded');
